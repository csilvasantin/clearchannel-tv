#!/usr/bin/env python3
"""Read native JSONL observations. Reports media transport timing, never acoustic PASS."""
import argparse
import bisect
import hashlib
import json
import math
from collections import Counter
from pathlib import Path


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def canonical_id(value):
    value = str(value or "")
    if value.startswith("default:"):
        return value[len("default:"):]
    if value.startswith("preview:"):
        parts = value.split(":", 2)
        if len(parts) == 3 and parts[1].isdigit():
            return parts[2]
    return value


def percentile(values, q):
    if not values:
        return None
    values = sorted(values)
    index = (len(values) - 1) * q
    lo, hi = math.floor(index), math.ceil(index)
    return values[lo] + (values[hi] - values[lo]) * (index - lo)


def distribution(values):
    absolute = [abs(v) for v in values]
    return {"count": len(values), "absoluteMs": {
        "p50": percentile(absolute, .5), "p95": percentile(absolute, .95),
        "max": max(absolute, default=None)},
        "signedMs": {"min": min(values, default=None), "max": max(values, default=None),
                     "median": percentile(values, .5)}}


def rejection(sample, max_clock_age_ms):
    if sample.get("clockValid") is not True:
        return "clock-invalid"
    if sample.get("foreground") is not True:
        return "not-foreground"
    if sample.get("holdover") is not False:
        return "holdover-or-missing"
    if sample.get("isPlaying") is not True or sample.get("state") != "READY":
        return "not-playing-ready"
    if sample.get("seekPending") is not False or sample.get("correction") in ("seek", "initial-seek"):
        return "seek-or-correction"
    if "audioAdvancingConfirmed" in sample and sample["audioAdvancingConfirmed"] is not True:
        return "audio-not-advancing"
    if sample.get("suppressionReason") not in (0, "NONE", "none"):
        return "suppressed-or-missing"
    for key in ("serverNowMs", "actualPositionMs", "targetPositionMs", "rate", "clockAgeMs",
                "clockRttMs", "uncertaintyMs", "sampleDelayMs", "mediaDurationMs", "epochMs"):
        if not number(sample.get(key)):
            return "invalid-" + key
    if sample["rate"] <= 0 or sample["mediaDurationMs"] <= 0 or sample["actualPositionMs"] < 0:
        return "invalid-media-position"
    if sample["clockAgeMs"] < 0 or sample["clockAgeMs"] > max_clock_age_ms:
        return "clock-too-old"
    if min(sample["clockRttMs"], sample["uncertaintyMs"], sample["sampleDelayMs"]) < 0:
        return "invalid-uncertainty"
    if not sample.get("groupId") or not sample.get("playlistSha256") or not canonical_id(sample.get("itemId")):
        return "missing-session-identity"
    if not isinstance(sample.get("index"), int) or not isinstance(sample.get("targetIndex"), int):
        return "missing-slot-index"
    if sample["index"] != sample["targetIndex"]:
        return "wrong-target-item"
    return None


def circular_difference(a, b, duration):
    return (a - b + duration / 2) % duration - duration / 2


def uncertainty(sample):
    # A full sampling delay is conservative when the JS/native sample midpoint is unknown.
    return (sample["uncertaintyMs"] + sample["sampleDelayMs"]) * sample["rate"]


def target_error(sample):
    target = sample.get("effectiveTargetPositionMs", sample.get("targetMediaPositionMs", sample["targetPositionMs"]))
    if not number(target):
        target = sample["targetPositionMs"]
    return circular_difference(sample["actualPositionMs"], target, sample["mediaDurationMs"])


def editorial_target(sample):
    # iOS initially exposed raw slot time separately from its modulo media alias.
    return sample.get("targetSlotPositionMs", sample["targetPositionMs"])


def project(sample, timestamp):
    return (sample["actualPositionMs"] + (timestamp - sample["serverNowMs"]) * sample["rate"]) % sample["mediaDurationMs"]


def load_jsonl(path):
    samples, errors = [], []
    data = Path(path).read_bytes()
    for line_no, raw in enumerate(data.splitlines(), 1):
        if not raw.strip():
            continue
        try:
            sample = json.loads(raw)
            if not isinstance(sample, dict) or not number(sample.get("serverNowMs")):
                raise ValueError("missing finite serverNowMs")
            samples.append(sample)
        except (ValueError, UnicodeDecodeError) as exc:
            errors.append({"line": line_no, "error": str(exc)[:160]})
    return sorted(samples, key=lambda s: s["serverNowMs"]), {
        "file": str(Path(path).resolve()), "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data), "parsed": len(samples), "parseErrors": errors}


def load_jsonls(paths):
    values, reports, seen, duplicates = [], [], set(), 0
    for path in paths:
        samples, report = load_jsonl(path); reports.append(report)
        for sample in samples:
            key = json.dumps(sample, sort_keys=True, separators=(",", ":"))
            if key in seen:
                duplicates += 1
                continue
            seen.add(key); values.append(sample)
    return sorted(values, key=lambda s: s["serverNowMs"]), {"files": reports, "duplicatesRemoved": duplicates}


def target_report(samples, max_clock_age_ms):
    rejected, values, bounds, times = Counter(), [], [], []
    for sample in samples:
        reason = rejection(sample, max_clock_age_ms)
        if reason:
            rejected[reason] += 1
            continue
        values.append(target_error(sample)); bounds.append(uncertainty(sample)); times.append(sample["serverNowMs"])
    drift = None
    if len(times) > 1 and times[-1] > times[0]:
        x = [(t - times[0]) / 60000 for t in times]
        mx, my = sum(x) / len(x), sum(values) / len(values)
        den = sum((v - mx) ** 2 for v in x)
        if den:
            drift = sum((a - mx) * (b - my) for a, b in zip(x, values)) / den
    return {"samples": len(samples), "rejected": dict(rejected), "targetError": distribution(values),
            "positionClockBoundMs": {"p50": percentile(bounds, .5), "p95": percentile(bounds, .95), "max": max(bounds, default=None)},
            "stableSampleSpanMs": times[-1] - times[0] if times else 0,
            "signedTargetDriftMsPerMinute": drift}


def analyze(ios, android, max_gap_ms=500, max_clock_age_ms=45000):
    # Match nearest observations in time before filtering identity/state. Otherwise a
    # long player stall could be hidden by finding a much older same-item observation.
    unused = list(range(len(android))); android_times = [s["serverNowMs"] for s in android]
    rejected, pairs = Counter(), []
    for left in ios:
        if not unused:
            rejected["no-android-observation"] += 1
            continue
        times = [android_times[i] for i in unused]
        point = bisect.bisect_left(times, left["serverNowMs"])
        choices = [p for p in (point - 1, point) if 0 <= p < len(unused)]
        nearest = min(choices, key=lambda p: abs(times[p] - left["serverNowMs"]))
        index = unused[nearest]; right = android[index]
        if abs(right["serverNowMs"] - left["serverNowMs"]) > max_gap_ms:
            rejected["timestamp-gap"] += 1
            continue
        unused.pop(nearest)
        reason = rejection(left, max_clock_age_ms) or rejection(right, max_clock_age_ms)
        if reason:
            rejected[reason] += 1
            continue
        if any(left[key] != right[key] for key in ("groupId", "playlistSha256", "epochMs")):
            rejected["session-mismatch"] += 1
            continue
        if canonical_id(left["itemId"]) != canonical_id(right["itemId"]) or left["index"] != right["index"]:
            rejected["item-mismatch"] += 1
            continue
        if abs(left["mediaDurationMs"] - right["mediaDurationMs"]) > 250:
            rejected["media-duration-mismatch"] += 1
            continue
        common = max(left["serverNowMs"], right["serverNowMs"])
        # targetPosition is editorial, modulo actual duration for shorter repeating audio.
        editorial_left = editorial_target(left) + common - left["serverNowMs"]
        editorial_right = editorial_target(right) + common - right["serverNowMs"]
        if abs(editorial_left - editorial_right) > max(5, uncertainty(left) + uncertainty(right)):
            rejected["target-disagreement"] += 1
            continue
        duration = min(left["mediaDurationMs"], right["mediaDurationMs"])
        skew = circular_difference(project(right, common), project(left, common), duration)
        bound = uncertainty(left) + uncertainty(right)
        pairs.append({"serverNowMs": common, "itemId": canonical_id(left["itemId"]), "index": left["index"],
                      "androidMinusIosMs": skew, "positionClockBoundMs": bound,
                      "minimumAbsoluteSkewCompatibleMs": max(0, abs(skew) - bound),
                      "maximumAbsoluteSkewCompatibleMs": abs(skew) + bound,
                      "sampleGapMs": abs(right["serverNowMs"] - left["serverNowMs"]),
                      "iosActualPositionMs": left["actualPositionMs"], "androidActualPositionMs": right["actualPositionMs"],
                      "iosRate": left["rate"], "androidRate": right["rate"]})
    values = [p["androidMinusIosMs"] for p in pairs]; bounds = [p["positionClockBoundMs"] for p in pairs]
    return {"status": "MEASURED_TRANSPORT_ONLY" if pairs else "INCONCLUSIVE", "acousticVerification": False,
            "method": "Nearest timestamp, then same session/item/index and stable real decoder state; project with measured rate to later remote timestamp; circular media-position difference.",
            "parameters": {"maxPairGapMs": max_gap_ms, "maxClockAgeMs": max_clock_age_ms},
            "ios": target_report(ios, max_clock_age_ms), "android": target_report(android, max_clock_age_ms),
            "pair": {"skew": distribution(values), "rejected": dict(rejected), "unmatchedAndroidSamples": len(unused),
                     "positionClockBoundMs": {"p50": percentile(bounds, .5), "p95": percentile(bounds, .95), "max": max(bounds, default=None)},
                     "sampleSpanMs": pairs[-1]["serverNowMs"] - pairs[0]["serverNowMs"] if pairs else 0},
            "observations": pairs,
            "limits": ["No acoustic capture: positions do not prove identical sound arrival from speakers.",
                       "Clock bounds are supplied estimates plus conservative full sample delay, not experimentally proven absolute accuracy.",
                       "Projection assumes reported rate stays constant within maxPairGapMs; seeks/buffering/holdover are rejected and counted.",
                       "No automatic PASS threshold; convergence/transition and real acoustic acceptance remain separate."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ios", required=True, type=Path, nargs="+")
    parser.add_argument("--android", required=True, type=Path, nargs="+")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--max-gap-ms", type=float, default=500)
    parser.add_argument("--max-clock-age-ms", type=float, default=45000)
    args = parser.parse_args()
    if args.max_gap_ms <= 0 or args.max_clock_age_ms <= 0:
        parser.error("bounds must be positive")
    ios, ios_source = load_jsonls(args.ios); android, android_source = load_jsonls(args.android)
    result = analyze(ios, android, args.max_gap_ms, args.max_clock_age_ms)
    result["sources"] = {"ios": ios_source, "android": android_source}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "pairs": result["pair"]["skew"]["count"],
                      "absolutePairSkewMs": result["pair"]["skew"]["absoluteMs"], "output": str(args.out)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
